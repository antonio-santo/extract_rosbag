# This is a sample Python script.
import rosbag
import argparse
import yaml
import numpy as np
import pandas as pd
import os
import open3d as o3d
import rospy
from roslib import message
import sensor_msgs.point_cloud2 as pc2
import cv2
from cv_bridge import CvBridge, CvBridgeError

# Para instalar las librerias sueltas.
# pip install --ignore-installed  --extra-index-url https://rospypi.github.io/simple/ rospy rosbag


class EurocSaver():
    """
    Class that saves FIT information (fit file and video file) to EUROC format.
    """
    def __init__(self, euroc_directory=None):
        self.euroc_directory = euroc_directory
        self.odometry_directory = euroc_directory + '/robot0/odom'
        self.imu_directory = euroc_directory + '/robot0/imu0'
        self.gps_directory = euroc_directory + '/robot0/gps0'
        self.lidar_directory = euroc_directory + '/robot0/lidar'
        self.ground_truth_directory = euroc_directory + '/robot0/ground_truth'
        self.camera_directory = euroc_directory + '/robot0/camera'

        try:
            os.makedirs(self.lidar_directory + '/data')
        except OSError:
            print("Directory exists or creation failed", self.lidar_directory)
        try:
            os.makedirs(self.odometry_directory)
        except OSError:
            print("Directory exists or creation failed", self.odometry_directory)
        try:
            os.makedirs(self.gps_directory)
        except OSError:
            print("Directory exists or creation failed", self.gps_directory)
        try:
            os.makedirs(self.ground_truth_directory)
        except OSError:
            print("Directory exists or creation failed", self.ground_truth_directory)
        try:
            os.makedirs(self.imu_directory)
        except OSError:
            print("Directory exists or creation failed", self.imu_directory)
        try:
            os.makedirs(self.camera_directory + '/data')
        except OSError:
            print("Directory exists or creation failed", self.camera_directory)



    def save_odometry(self, bag_file, topic):
        epoch_list = []
        xyz_list = []
        q_list = []
        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            time_str = str(msg.header.stamp)
            epoch_list.append(time_str)
            xyz_list.append([msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z])
            q_list.append([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z,msg.pose.pose.orientation.w])

        xyz_list = np.array(xyz_list)
        q_list = np.array(q_list)
        raw_data = {'timestamp': epoch_list,
                    'x': xyz_list[:, 0],
                    'y': xyz_list[:, 1],
                    'z': xyz_list[:, 2],
                    'qx': q_list[:, 0],
                    'qy': q_list[:, 1],
                    'qz': q_list[:, 2],
                    'qw': q_list[:, 3]
                    }
        df = pd.DataFrame(raw_data, columns=['timestamp', 'x', 'y', 'z', 'qx', 'qy', 'qz', 'qw'])
        df.to_csv(self.odometry_directory + '/data.csv', index=False, header=['#timestamp [ns]',
                                                                              'x', 'y', 'z',
                                                                              'qx', 'qy', 'qz', 'qw'])
        print('\n---')

        return True


    def save_imu(self, bag_file, topic):
        epoch_list = []
        q_list = []
        covariance_list = []
        i = 0

        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            time_str=str(msg.header.stamp)
            epoch_list.append(time_str)
            q_list.append([msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w])
            covariance = np.reshape(msg.orientation_covariance, (3, 3))
            covariance_list.append(np.diag(covariance))

        q_list = np.array(q_list)
        covariance_list = np.array(covariance_list)
        raw_data = {'timestamp': epoch_list,
                    'qx': q_list[:, 0],
                    'qy': q_list[:, 1],
                    'qz': q_list[:, 2],
                    'qw': q_list[:, 3],
                    'covariance_d1': covariance_list[:, 0],
                    'covariance_d2': covariance_list[:, 1],
                    'covariance_d3': covariance_list[:, 2]
                    }
        df = pd.DataFrame(raw_data, columns=['timestamp', 'qx', 'qy', 'qz', 'qw', 'covariance_d1', 'covariance_d2',
                                             'covariance_d3'])
        df.to_csv(self.imu_directory + '/data.csv', index=False, header=['#timestamp [ns]',
                                                                         'qx', 'qy', 'qz', 'qw',
                                                                         'covariance_d1', 'covariance_d2',
                                                                         'covariance_d3'])
        print('\n---')

        return True


    def save_gps(self, bag_file, topic):
        epoch_list = []
        # list of xyz positions and quaternions
        gps_coords_list = []
        covariance_list = []
        mode = []
        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            if np.isnan(msg.latitude) == False:
                time_str = str(msg.header.stamp)
                epoch_list.append(time_str)
                gps_coords_list.append([msg.latitude, msg.longitude, msg.altitude])
                mode.append(msg.status.status)
                covariance = np.reshape(msg.position_covariance, (3, 3))
                covariance_list.append(np.diag(covariance))
            else:
                time_str = str(msg.header.stamp)
                # GPS coords.
                epoch_list.append(time_str)
                gps_coords_list.append([0.0, 0.0, 0.0])
                mode.append(msg.status.status)
                covariance = np.reshape(msg.position_covariance, (3, 3))
                covariance_list.append(np.diag(covariance))

        gps_coords_list = np.array(gps_coords_list)
        covariance_list = np.array(covariance_list)
        raw_data = {'timestamp': epoch_list,
                    'latitude': gps_coords_list[:, 0],
                    'longitude': gps_coords_list[:, 1],
                    'altitude': gps_coords_list[:, 2],
                    'covariance_d1': covariance_list[:, 0],
                    'covariance_d2': covariance_list[:, 1],
                    'covariance_d3': covariance_list[:, 2],
                    'status': mode
                    }
        df = pd.DataFrame(raw_data,
                          columns=['timestamp', 'latitude', 'longitude', 'altitude', 'covariance_d1', 'covariance_d2',
                                   'covariance_d3', 'status'])
        df.to_csv(self.gps_directory + '/data.csv', index=False,
                  header=['#timestamp [ns]', 'latitude', 'longitude', 'altitude',
                          'covariance_d1', 'covariance_d2', 'covariance_d3', 'status'])
        print('\n---')

        return True


    def save_lidar(self, bag_file, topic):
        epoch_list=[]
        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            time_str = str(msg.header.stamp)
            epoch_list.append(time_str)
            field_names = [field.name for field in msg.fields]
            print(field_names)
            points = list(pc2.read_points(msg, skip_nans=True, field_names=field_names))
            if len(points) == 0:
                print("Converting an empty cloud")
                return None

            pcd_array = np.asarray(points)
            cloud = pcd_array[:, 0:3]
            pointcloud = o3d.geometry.PointCloud()
            pointcloud.points = o3d.utility.Vector3dVector(cloud)
            output_directory = self.lidar_directory + '/data/'
            output_filename = output_directory + time_str + ".pcd"
            o3d.io.write_point_cloud(output_filename, pointcloud)

            raw_data = {'x': pcd_array[:,0],
                        'y': pcd_array[:,1],
                        'z': pcd_array[:,2],
                        'intensity': pcd_array[:,3],
                        't': pcd_array[:,4],
                        'reflectivity': pcd_array[:,5],
                        'ring': pcd_array[:,6],
                        'ambient': pcd_array[:,7],
                        'range':pcd_array[:,8]}

            df = pd.DataFrame(raw_data,columns=['x', 'y', 'z', 'intensity', 't', 'reflectivity','ring', 'ambient','range'])

            df.to_csv(self.lidar_directory + '/data/' + time_str + ".csv", index=False,
                      header=['x', 'y', 'z', 'intensity', 't',
                              'reflectivity', 'ring', 'ambient', 'range'])
        ##TIMESTAMP ONLY
        raw_data2 = {'timestamp': epoch_list}
        df = pd.DataFrame(raw_data2,columns=['timestamp'])
        df.to_csv(self.lidar_directory + "data.csv", index=False,header=['#timestamp [ns]'])

        print('\n---')

        return True


    def save_ground_truth(self, bag_file, topic):
        i = 0
        epoch_list = []
        # list of xyz positions and quaternions
        xyz_list = []
        q_list = []

        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            time_str = str(msg.header.stamp)
            # Odometry.
            epoch_list.append(time_str)
            xyz_list.append([msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z])
            q_list.append(
                [msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z,
                 msg.pose.pose.orientation.w])

        xyz_list = np.array(xyz_list)
        q_list = np.array(q_list)
        raw_data = {'timestamp': epoch_list,
                    'x': xyz_list[:, 0],
                    'y': xyz_list[:, 1],
                    'z': xyz_list[:, 2],
                    'qx': q_list[:, 0],
                    'qy': q_list[:, 1],
                    'qz': q_list[:, 2],
                    'qw': q_list[:, 3]
                    }
        df = pd.DataFrame(raw_data, columns=['timestamp', 'x', 'y', 'z', 'qx', 'qy', 'qz', 'qw'])
        df.to_csv(self.ground_truth_directory + '/data.csv', index=False, header=['#timestamp [ns]',
                                                                                  'x', 'y', 'z',
                                                                                  'qx', 'qy', 'qz', 'qw'])
        print('\n---')



    def save_camera(self, bag_file, topic):

        for topic, msg, t in bag_file.read_messages(topics=[topic]):
            bridge = CvBridge()
            cv_image = bridge.imgmsg_to_cv2(msg, "bgr8")
            cv2.imwrite(self.camera_directory + '/data/' +str(msg.header.stamp)+'.png', cv_image)



if __name__ == '__main__':

    ###########TOPICS TO EXTRACT############
    with open(r'config.yaml') as file:
        param_list = yaml.load(file, Loader=yaml.FullLoader)
        print(param_list)

    topic_name_ground_truth = param_list.get('topic_name_ground_truth')
    topic_name_point_cloud = param_list.get('topic_name_point_cloud')
    topic_name_odometry = param_list.get('topic_name_odometry')
    topic_name_gps = param_list.get('topic_name_gps')
    topic_name_imu = param_list.get('topic_name_imu')
    topic_name_camera = param_list.get('topic_name_camera')

    print('POINT CLOUD TOPIC: ', topic_name_point_cloud)
    print('ODOMETRY TOPIC: ', topic_name_odometry)
    print('GPS TOPIC: ', topic_name_gps)
    print('IMU TOPIC: ', topic_name_imu)
    print('CAMERA TOPIC: ', topic_name_camera)

    #READ ROSBAG FILE

    path = "/home/arvc/prueba"
    eurocsaver = EurocSaver(euroc_directory=path)

    bag = rosbag.Bag('/home/arvc/2022-10-31-11-16-17.bag')

    #DESCOMENTAR EL QUE SE QUIERA EXTRAER

    #eurocsaver.save_odometry(bag, topic_name_odometry)
    #eurocsaver.save_gps(bag, topic_name_gps)
    #eurocsaver.save_imu(bag, topic_name_imu)
    #eurocsaver.save_lidar(bag,topic_name_point_cloud)
    eurocsaver.save_camera(bag, topic_name_camera)
    #eurocsaver.save_ground_truth(bag, topic_name_ground_truth) just for simulation




